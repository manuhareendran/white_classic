(function($) {

  if ($.fn.CSFRAMEWORK_RELOAD_PLUGINS) {
    $('.vc_ui-panel-content').CSFRAMEWORK_RELOAD_PLUGINS();
  }

})(jQuery);
